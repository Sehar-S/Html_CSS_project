# 📚 HTML & CSS Tutorial Portfolio

A hands-on learning project covering HTML and CSS fundamentals, built as part of my web development journey.

---

## 🚀 Live Demo

> Open `index.html` in your browser to view the project, or deploy to GitHub Pages.

---

## 📁 Project Structure

```
HTML_Tutorial/
├── index.html                  ← Main landing page
├── css/
│   ├── main.css                ← Landing page styles
│   └── shared.css              ← Shared nav/layout styles for all pages
├── pages/
│   ├── 01-html-basics.html     ← HTML fundamentals
│   ├── 02-forms.html           ← HTML form elements
│   ├── 03-css-styling.html     ← CSS selectors, colors, fonts, borders
│   ├── 04-animations.html      ← CSS keyframe animations
│   ├── 05-pseudo-icons.html    ← Pseudo-classes & Font Awesome icons
│   └── 06-layout.html          ← Float, position, and Flexbox
├── images/                     ← Project images
└── README.md                   ← This file
```

---

## ✅ Topics Covered

### HTML
- Document structure (`<!DOCTYPE>`, `<html>`, `<head>`, `<body>`)
- Headings (`h1`–`h6`), paragraphs, horizontal rules
- Links (`<a>` tag, `href`, `target="_blank"`)
- Images (`<img>`, `alt` text, `width`/`height`)
- Text formatting (`<b>`, `<i>`, `<u>`, `<big>`, `<small>`, `<sub>`, `<sup>`)
- Preformatted text (`<pre>`)
- Tables (`<table>`, `<thead>`, `<tbody>`, `<th>`, `<td>`, `<caption>`)
- Embedded video (`<iframe>`)
- Forms: `text`, `password`, `radio`, `checkbox`, `select`, `textarea`, `submit`
- HTML comments (`<!-- -->`)

### CSS
- Selectors: element, `#id`, `.class`
- Colors: named, hex, rgb, rgba
- Fonts: `font-family`, `font-size`, `font-weight`, `font-style`
- Text: `text-align`, `text-decoration`, `text-shadow`
- Box model: `padding`, `margin`, `border`, `border-radius`
- Backgrounds: solid, `linear-gradient`, `radial-gradient`
- Pseudo-classes: `:hover`, `:active`, `:visited`, `:link`, `:focus`, `:nth-child()`
- CSS Animations: `@keyframes`, `animation-name`, `animation-duration`, `animation-iteration-count`
- Transforms: `rotate`, `scale`, `translate`
- Layout: `float`, `clear`, `position` (relative/absolute/sticky)
- Flexbox: `display: flex`, `flex-direction`, `justify-content`, `align-items`, `gap`
- CSS Variables (`--custom-property`)
- Responsive design with `@media` queries

### Other
- Font Awesome icons (solid and brand icons)
- Google Fonts import
- Responsive iframe (16:9 video embed)
- Relative vs absolute file paths

---

## 🛠️ How to Run Locally

1. Clone or download this repository
2. Open `index.html` in any modern browser (Chrome, Firefox, Edge)
3. No build tools or server required — pure HTML & CSS!

---

## 🌐 Deploy to GitHub Pages

1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Set Source to: **Deploy from a branch → main → / (root)**
4. Your site will be live at: `https://your-username.github.io/HTML_Tutorial/`

---

## 💡 Key Learnings

- HTML gives a page **structure and meaning**
- CSS gives a page **style and visual design**
- CSS pseudo-classes target elements based on **state** (hover, focus, etc.)
- CSS animations use **@keyframes** to define step-by-step visual changes
- **Flexbox** is the modern standard for arranging elements in a layout
- Always add `alt` text to images for **accessibility**
- Use **semantic HTML** (proper heading order, labels on inputs) for better SEO and accessibility

---

## 📬 Contact

- Email: your-email@example.com
- GitHub: [your-username](https://github.com/your-username)

---

*Built with ❤️ while learning HTML & CSS*
